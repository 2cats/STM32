#define STA_OK	1
#define STA_ERR	0
enum {
	USART_SEND_ERROR,
	USART_RECV_ERROR,
	
}