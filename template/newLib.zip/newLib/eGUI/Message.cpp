/*
 * Message.cpp
 *
 *  Created on: 2014��6��27��
 *      Author: Administrator
 */

#include "Message.h"

Message::Message() {
	// TODO Auto-generated constructor stub

}
