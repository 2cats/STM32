#ifndef _INPUTDEVICE_H
#define _INPUTDEVICE_H
#include "MenuWidget.h"
void OnKey(MenuWidget *menuWidget,unsigned char c);
#endif