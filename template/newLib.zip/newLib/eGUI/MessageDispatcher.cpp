/*
 * MessageDispatcher.cpp
 *
 *  Created on: 2014��6��27��
 *      Author: Administrator
 */

#include "MessageDispatcher.h"

MessageDispatcher::MessageDispatcher() {
	// TODO Auto-generated constructor stub

}

MessageDispatcher::~MessageDispatcher() {
	// TODO Auto-generated destructor stub
}

