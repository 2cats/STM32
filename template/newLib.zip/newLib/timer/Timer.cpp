#include "Timer.h"
Timer::Timer(TIMER_ConfBase& conf):config(conf)
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	conf.RCC_APBxPeriphClockCmd(conf.RCC_TIM,ENABLE);

	TIM_TimeBaseStructure.TIM_Period = conf.TIM_Period ; //�趨�������Զ���װֵ 
	TIM_TimeBaseStructure.TIM_Prescaler =conf.TIM_Prescaler; 	//Ԥ��Ƶ��   
	TIM_TimeBaseStructure.TIM_ClockDivision = conf.TIM_ClockDivision; //����ʱ�ӷָ�:TDTS = Tck_tim
	TIM_TimeBaseStructure.TIM_CounterMode = conf.TIM_CounterMode;  //TIM���ϼ���ģʽ
	TIM_TimeBaseInit(conf.TIMx, &TIM_TimeBaseStructure); //����TIM_TimeBaseInitStruct��ָ���Ĳ�����ʼ��TIMx��ʱ�������λ

	NVIC_InitStructure.NVIC_IRQChannel = conf.TIMx_IRQn;  //TIM3�ж�
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;  //��ռ���ȼ�2��
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;  //�����ȼ�0��
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; //IRQͨ����ʹ��
	NVIC_Init(&NVIC_InitStructure);  //����NVIC_InitStruct��ָ���Ĳ�����ʼ������NVIC�Ĵ��� 
	TIM_ITConfig(conf.TIMx,TIM_IT_Update,ENABLE);//���������ж� ,����CC1IE�����ж�	
	TIM_ClearITPendingBit(conf.TIMx,TIM_IT_Update); //����жϱ�־λ

	//defaultDoEvery=doIt;
	TIM_Cmd(conf.TIMx,ENABLE ); 
}
void(*TIM_UP_callback[5])(void);
unsigned long ticksCount[5];

unsigned long Timer::ticks()
{
	return ticksCount[config.id];
}
std::map<int,VV_CallBack_TypeDef>cb_maps[5];
void Timer::doEvery(int x_ticks,void (*cb)(void))
{
	cb_maps[config.id].insert( std::pair <int, VV_CallBack_TypeDef> (x_ticks,cb));
}
void ticks_callback_proc(int id)
{
	std::map<int,VV_CallBack_TypeDef>::iterator it=cb_maps[id].begin();
	while(it!=cb_maps[id].end())
	{
		if(ticksCount[id]%it->first==0&&it->second!=0)
		{
			it->second();
		}
		it++;
	}
}
extern "C"
{
	void TIM1_UP_IRQHandler()
	{
		if(TIM_UP_callback[1]!=0)
		{
			TIM_UP_callback[1]();
		}
		ticksCount[1]++;
		ticks_callback_proc(1);
		//need softclear
		TIM1->SR&=~((uint16_t)1);
	}
	void TIM2_IRQHandler()
	{
		if(TIM_UP_callback[2]!=0)
		{
			TIM_UP_callback[2]();
		}
		ticksCount[2]++;
		ticks_callback_proc(2);
		//need softclear
		TIM2->SR&=~((uint16_t)1);
	}
	void TIM3_IRQHandler()
	{
		if(TIM_UP_callback[3]!=0)
		{
			TIM_UP_callback[3]();
		}
		ticksCount[3]++;
		ticks_callback_proc(3);
		//need softclear
		TIM3->SR&=~((uint16_t)1);
	}		
	void TIM4_IRQHandler()
	{
		if(TIM_UP_callback[4]!=0)
		{
			TIM_UP_callback[4]();
		}
		ticksCount[4]++;
		ticks_callback_proc(4);
		//need softclear
		TIM4->SR&=~((uint16_t)1);
	}		    
}	