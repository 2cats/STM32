#ifndef __TIMER_H
#define __TIMER_H 


/************START**************/
	 
#include <stm32f10x.h>
#include "config/Configure.h"
#include <map>

typedef void (*VV_CallBack_TypeDef)(void) ;
class Timer
{
public:
		Timer(TIMER_ConfBase& conf);
		unsigned long  ticks();
		void doEvery(int x_ticks,void (*cb)(void));
		void pause();
		void resume();

private:
	TIMER_ConfBase config;

};
	 
	 
	 
/*************END*************/
#endif