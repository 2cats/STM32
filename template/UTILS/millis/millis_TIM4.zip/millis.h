#ifndef _MILLIS_H
#define _MILLIS_H
//!millis 50���ʧЧ
#include "stm32f10x_rcc.h"


void MILLIS_Init(void);
unsigned long millis(void);

#endif
