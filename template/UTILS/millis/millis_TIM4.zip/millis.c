#include "millis.h"
#include "stm32f10x_tim.h"
#include "stm32f10x_dma.h"
//ռ��TIM4��1ms�жϣ�
//!millis 50���ʧЧ
u32 _MILLIS_=0;
//u16 _MILLIS_60sCounter_=0;
//u8 FAKEBUF[2];
//DMA1 CHA7
//void TIM4_DMA_UP_Configure(void)
//{
//		NVIC_InitTypeDef NVIC_InitStructure;
//		DMA_InitTypeDef DMA_InitStructure; 

//		RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);//DMAʱ��

//		DMA_DeInit(DMA1_Channel7);
//		DMA_InitStructure.DMA_PeripheralBaseAddr = (u32)FAKEBUF; //����Ĵ�������ַ
//		DMA_InitStructure.DMA_MemoryBaseAddr =(u32)FAKEBUF+1; //RAM����ַ
//		DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC; //���䷽��
//		DMA_InitStructure.DMA_BufferSize = 0xEA60;//Size 1000ms*60=60s
//		DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable; //����ĵ�ַ�Ƿ��Զ�����
//		DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Disable; //RAM�ĵ�ַ�Ƿ��Զ�����
//		DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
//		DMA_InitStructure.DMA_MemoryDataSize =DMA_MemoryDataSize_Byte; //���䵥λ!!!!!!!!

//		DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;//DMA_Mode_Normal; //�Ƿ񲻶ϴ���
//		DMA_InitStructure.DMA_Priority = DMA_Priority_Medium; //������
//		DMA_InitStructure.DMA_M2M = DMA_M2M_Enable; //�ǲ���RAM2RAM
//		DMA_Init(DMA1_Channel7, &DMA_InitStructure); 

//		DMA_ITConfig(DMA1_Channel7,DMA_IT_TC,ENABLE ); //DMA�жϣ�������NVIC��
//		NVIC_InitStructure.NVIC_IRQChannel = DMA1_Channel7_IRQn;     //TIM4�ж� 
//		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;    //��ռ���ȼ�0�� 
//		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;                  //�����ȼ�0�� 
//		NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;                 //IRQ ͨ����ʹ�� 
//		NVIC_Init(&NVIC_InitStructure);     
//		DMA_Cmd(DMA1_Channel7,ENABLE);//����DMA
//}
void MILLIS_Init()
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	NVIC_InitTypeDef NVIC_InitStructure;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE); //ʱ��ʹ��
	TIM_DeInit(TIM4);
	TIM_InternalClockConfig(TIM4);
	TIM_TimeBaseInitStruct.TIM_Period=1000;
	TIM_TimeBaseInitStruct.TIM_Prescaler=71;
	TIM_TimeBaseInitStruct.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseInitStruct);
	TIM_ITConfig(TIM4,TIM_IT_Update,ENABLE);

	TIM_DMACmd(TIM4,TIM_IT_Update,ENABLE);
 

	TIM_Cmd(TIM4,ENABLE);
//	TIM4_DMA_UP_Configure();
//  //TIM4->DIER |= 0x4000;

	NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;                     //TIM4�ж� 
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;    //��ռ���ȼ�0�� 
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;                  //�����ȼ�0�� 
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;                 //IRQ ͨ����ʹ�� 
	NVIC_Init(&NVIC_InitStructure);                                                     //��ʼ��NVIC�Ĵ���

}

unsigned long millis()//1MS
{
	return _MILLIS_;
}
void TIM4_IRQHandler()
{
	if(TIM4->SR&1)
	{
		TIM4->SR&=~1;
	 _MILLIS_++;
	}
}
//void DMA1_Channel7_IRQHandler()
//{
////	if(DMA_GetITStatus(DMA1_IT_TC7)==SET)
////	{
////		_MILLIS_60sCounter_++;
////		DMA_ClearITPendingBit(DMA1_IT_TC7);
////	}
//	if(DMA1->ISR&0x02000000)
//	{
//		_MILLIS_60sCounter_++;
//	//	DMA1->IFCR&=0x02000000;//error
//		DMA1->IFCR=0x02000000;
//	}
//}
